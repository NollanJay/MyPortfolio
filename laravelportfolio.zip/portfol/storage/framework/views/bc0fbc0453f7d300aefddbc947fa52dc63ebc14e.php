<?php if (isset($component)) { $__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da = $component; } ?>
<?php $component = $__env->getContainer()->make(App\View\Components\AppLayout::class, []); ?>
<?php $component->withName('app-layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes([]); ?>
<section class="text-gray-600 body-font">
  <div class="container px-5 py-24 mx-auto flex flex-wrap">
    <div class="flex w-full mb-20 flex-wrap">
      <h1 class="sm:text-3xl text-2xl font-medium title-font text-gray-900 lg:w-1/3 lg:mb-0 mb-4"data-aos="fade-up">My Gallery</h1>
      <p class="lg:pl-6 lg:w-2/3 mx-auto leading-relaxed text-base"data-aos="fade-up">This Gallery shows some of my photos that highlights my life. It shows some highlights of the important events that capture the best moments. Some are my photos when I am travelling and others are from the school events.</p>
    </div>
    <div class="flex flex-wrap md:-m-2 -m-1">
      <div class="flex flex-wrap w-1/2">
        <div class="md:p-2 p-1 w-1/2" data-aos="fade-up" data-aos-delay="150">
          <img alt="gallery" class="w-full object-cover h-full object-center block" src="/img/j1.jpg">
        </div>
        <div class="md:p-2 p-1 w-1/2" data-aos="fade-up">
          <img alt="gallery" class="w-full object-cover h-full object-center block" src="/img/j2.jpg">
        </div>
        <div class="md:p-2 p-1 w-full" data-aos="fade-up" data-aos="fade-up">
          <img alt="gallery" class="w-full h-full object-cover object-center block" src="/img/j3.jpg">
        </div>
      </div>
      <div class="flex flex-wrap w-1/2">
        <div class="md:p-2 p-1 w-full" data-aos="fade-up" data-aos-delay="150">
          <img alt="gallery" class="w-full h-full object-cover object-center block" src="/img/j4.jpg">
        </div>
        <div class="md:p-2 p-1 w-1/2" data-aos="fade-up">
          <img alt="gallery" class="w-full object-cover h-full object-center block" src="/img/j5.jpg">
        </div>
        <div class="md:p-2 p-1 w-1/2" data-aos="fade-up">
          <img alt="gallery" class="w-full object-cover h-full object-center block" src="/img/j6.jpg">
        </div>
      </div>
    </div>
  </div>
</section>


 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da)): ?>
<?php $component = $__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da; ?>
<?php unset($__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da); ?>
<?php endif; ?>
<?php /**PATH C:\xampp\htdocs\cms\resources\views/gallery.blade.php ENDPATH**/ ?>