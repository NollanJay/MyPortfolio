<?php if (isset($component)) { $__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da = $component; } ?>
<?php $component = $__env->getContainer()->make(App\View\Components\AppLayout::class, []); ?>
<?php $component->withName('app-layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes([]); ?>

<!-- HEADER-->
<link rel="stylesheet" href="https://unpkg.com/aos@next/dist/aos.css" />

<section class="text-gray-600 body-font">
  <div class="container px-5 py-24 mx-auto" data-aos="fade-up">
    <div class="text-center mb-20">
      <h1 class="sm:text-3xl text-2xl font-medium title-font text-gray-900 mb-4"  >Welcome to My sfse Background</h1>
      <p class="text-base leading-relaxed xl:w-2/4 lg:w-3/4 mx-auto text-gray-500s">This page is intended to introduce myself, my personal background, educational attainment, My skills and my Portfolio.</p>
      <div class="flex mt-6 justify-center">
        <div class="w-16 h-1 rounded-full bg-indigo-500 inline-flex"></div>
      </div>
    </div>
    <div class="flex flex-wrap sm:-m-4 -mx-4 -mb-10 -mt-4 md:space-y-0 space-y-6"data-aos="fade-up">
      <div class="p-4 md:w-1/3 flex flex-col text-center items-center">
        <div class="w-20 h-20 inline-flex items-center justify-center rounded-full bg-indigo-100 text-indigo-500 mb-5 flex-shrink-0">
          <img src="/img/person.png">
        </div>
        <div class="flex-grow">
          <h2 class="text-gray-900 text-lg title-font font-medium mb-3">Personal background</h2>
          <p class="leading-relaxed text-base">Hi my name is Nollan Jay D. Galicia, 21 years of age from Island Garden City of Samal. I am the 2nd child from my three (3) siblings. My Mother's name is ...</p>
          <a class="mt-3 text-indigo-500 inline-flex items-center">Read More
            <svg fill="none" stroke="currentColor" stroke-linecap="round" stroke-linejoin="round" stroke-width="2" class="w-4 h-4 ml-2" viewBox="0 0 24 24">
              <path d="M5 12h14M12 5l7 7-7 7"></path>
            </svg>
          </a>
        </div>
      </div>
      <div class="p-4 md:w-1/3 flex flex-col text-center items-center">
        <div class="w-20 h-20 inline-flex items-center justify-center rounded-full bg-indigo-100 text-indigo-500 mb-5 flex-shrink-0">
          <img src="/img/educ.png">
        </div>
        <div class="flex-grow">
          <h2 class="text-gray-900 text-lg title-font font-medium mb-3">Educational Attainment</h2>
          <p class="leading-relaxed text-base">I studied Elementary in Angel Villarica Elementary School and Nieves Villarica National High School for my Junior and Senior high. Currently I am Studying...</p>
          <a class="mt-3 text-indigo-500 inline-flex items-center">Read More
            <svg fill="none" stroke="currentColor" stroke-linecap="round" stroke-linejoin="round" stroke-width="2" class="w-4 h-4 ml-2" viewBox="0 0 24 24">
              <path d="M5 12h14M12 5l7 7-7 7"></path>
            </svg>
          </a>
        </div>
      </div>
      <div class="p-4 md:w-1/3 flex flex-col text-center items-center">
        <div class="w-20 h-20 inline-flex items-center justify-center rounded-full bg-indigo-100 text-indigo-500 mb-5 flex-shrink-0">
          <img src="/img/skills.png">
        </div>
        <div class="flex-grow">
          <h2 class="text-gray-900 text-lg title-font font-medium mb-3">My Skills</h2>
          <p class="leading-relaxed text-base">Computer Literate &emsp;&emsp;&emsp; 10/10</p>
                                               Graphic Design &emsp;&emsp;&emsp;&emsp;&emsp;8/10</p>
                                               Adobe App &emsp;&emsp;&emsp;&emsp;&emsp;&emsp; 8/10</p>
                                               Photo Editing &emsp;&emsp;&emsp;&emsp;&emsp; 8/10</p>
                                               
          <a class="mt-3 text-indigo-500 inline-flex items-center">Read More
            <svg fill="none" stroke="currentColor" stroke-linecap="round" stroke-linejoin="round" stroke-width="2" class="w-4 h-4 ml-2" viewBox="0 0 24 24">
              <path d="M5 12h14M12 5l7 7-7 7"></path>
            </svg>
          </a>
        </div>
      </div>
    </div>
    <button class="flex mx-auto mt-16 text-white bg-indigo-500 border-0 py-2 px-8 focus:outline-none hover:bg-indigo-600 rounded text-lg">Learn More About Me</button>
  </div>
</section>

<!-- MID-->

<section class="text-gray-600 body-font" >
  <div class="container px-5 py-5 mx-auto">
    <div class="flex flex-col">
      <div class="h-1 bg-gray-200 rounded overflow-hidden">
        <div class="w-24 h-full bg-indigo-500"data-aos="fade-up"></div>
      </div>
      <div class="flex flex-wrap sm:flex-row flex-col py-6 mb-12"data-aos="fade-up">
        <h1 class="sm:w-2/5 text-gray-900 font-medium title-font text-2xl mb-2 sm:mb-0">My Portfolio</h1>
        <p class="sm:w-3/5 leading-relaxed text-base sm:pl-10 pl-0">This shows some of my work related to Graphic Designing, Website layout and design, Infographic materials, and User Interface Design.</p>
      </div>
    </div>
    <div class="flex flex-wrap sm:-m-4 -mx-4 -mb-10 -mt-4"data-aos="fade-up">
      <div class="p-4 md:w-1/3 sm:mb-0 mb-6">
        <div class="rounded-lg h-100 overflow-hidden">
          <img src="img/p1.png">
        </div>
        <h2 class="text-xl font-medium title-font text-gray-900 mt-5">Website Layout and Design</h2>
        <p class="text-base leading-relaxed mt-2">This is one example of my website layout design. It's a website for a travell blog and booking. It highlights beutiful Resort ...</p>
        <a class="text-indigo-500 inline-flex items-center mt-3">Read More
          <svg fill="none" stroke="currentColor" stroke-linecap="round" stroke-linejoin="round" stroke-width="2" class="w-4 h-4 ml-2" viewBox="0 0 24 24">
            <path d="M5 12h14M12 5l7 7-7 7"></path>
          </svg>
        </a>
      </div>
      <div class="p-4 md:w-1/3 sm:mb-0 mb-6">
        <div class="rounded-lg h-90 overflow-hidden">
          <img src="/img/p2.png">
        </div>
        <h2 class="text-xl font-medium title-font text-gray-900 mt-5">Infographic Poster Design</h2>
        <p class="text-base leading-relaxed mt-2">This is one example of my Infographic Poster design. It is a poster related to know Davao City next Destination...</p>
        <a class="text-indigo-500 inline-flex items-center mt-3">Read More
          <svg fill="none" stroke="currentColor" stroke-linecap="round" stroke-linejoin="round" stroke-width="2" class="w-4 h-4 ml-2" viewBox="0 0 24 24">
            <path d="M5 12h14M12 5l7 7-7 7"></path>
          </svg>
        </a>
      </div>
      <div class="p-4 md:w-1/3 sm:mb-0 mb-6">
        <div class="rounded-lg h-64 overflow-hidden">
          <img src="/img/p3.png">
        </div>
        <h2 class="text-xl font-medium title-font text-gray-900 mt-5">User Interface Design</h2>
        <p class="text-base leading-relaxed mt-2">This is one example of my User Interface Design for mobile devices. It is a user interface for a food Ordering and Delivery App.</p>
        <a class="text-indigo-500 inline-flex items-center mt-3">Read More
          <svg fill="none" stroke="currentColor" stroke-linecap="round" stroke-linejoin="round" stroke-width="2" class="w-4 h-4 ml-2" viewBox="0 0 24 24">
            <path d="M5 12h14M12 5l7 7-7 7"></path>
          </svg>
        </a>
      </div>
    </div>
  </div>
</section>


 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da)): ?>
<?php $component = $__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da; ?>
<?php unset($__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da); ?>
<?php endif; ?>
<?php /**PATH C:\School Files\3rd Year-2nd Sem\WS101\LaravelProjects\cms\resources\views/Welcome.blade.php ENDPATH**/ ?>